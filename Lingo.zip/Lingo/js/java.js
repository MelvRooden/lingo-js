var table = document.getElementsByTagName("table")[0];
for (var LO1 = 0; LO1 <= 4; LO1++) {
        var tr = document.createElement("TR");
        tr.setAttribute("id", "R" + LO1);
        for (var LO2 = 0; LO2 <= 4; LO2++) {
            var td = document.createElement("TD");
            var input = document.createElement("INPUT");
            input.setAttribute("id", 'R' + LO1 + 'L' + LO2);
            input.setAttribute("type", "text");
            input.setAttribute("maxLength", "1");
            td.appendChild(input);
            tr.appendChild(td);
        }
        table.appendChild(tr);
}
var woorden = ["lingo", "klaar", "appel", "taart", "draad", "actie", "avond", "brief", "groen", "paard", "puber"];
var woord = woorden[Math.floor(Math.random()*woorden.length)];

var Rows = 0;
var poging = ('R' + Rows + 'L1') + ('R' + Rows + 'L2') + ('R' + Rows + 'L3') + ('R' + Rows + 'L4') + ('R' + Rows + 'L5');

function check() {
    var R = 0;
    if (woord === poging) {
        ('R' + R + 'L' + 0).style.background = "orange";
        ('R' + R + 'L' + 1).style.background = "orange";
        ('R' + R + 'L' + 2).style.background = "orange";
        ('R' + R + 'L' + 3).style.background = "orange";
        ('R' + R + 'L' + 4).style.background = "orange";
    } else {
        checker();
    }
    R++;
}

function checker() {
    var pogingChecker = poging;
    for (var Letter = 0; Letter <= 4; Letter++) {
        if (poging.charAt(Letter) === woord.charAt(Letter)) {
            document.getElementById('R' + Rows +  'L' + Letter).style.background = "orange";
            poging.charAt(Letter = 0);
            pogingChecker.charAt(Letter = 9);
        } else if (poging.charAt(Letter) === woord.charAt(0)) {
            document.getElementById('R' + Rows + 'L' + Letter).style.background = "yellow";
            poging.charAt(Letter = 0);
            pogingChecker.charAt(Letter = 9);
        } else if (poging.charAt(Letter) === woord.charAt(1)) {
            document.getElementById('R' + Rows + 'L' + Letter).style.background = "yellow";
            poging.charAt(Letter = 0);
            pogingChecker.charAt(Letter = 9);
        } else if (poging.charAt(Letter) === woord.charAt(2)) {
            document.getElementById('R' + Rows + 'L' + Letter).style.background = "yellow";
            poging.charAt(Letter = 0);
            pogingChecker.charAt(Letter = 9);
        } else if (poging.charAt(Letter) === woord.charAt(3)) {
            document.getElementById('R' + Rows + 'L' + Letter).style.background = "yellow";
            poging.charAt(Letter = 0);
            pogingChecker.charAt(Letter = 9);
        } else if (poging.charAt(Letter) === woord.charAt(4)) {
            document.getElementById('R' + Rows + 'L' + Letter).style.background = "yellow";
            poging.charAt(Letter = 0);
            pogingChecker.charAt(Letter = 9);
        } else {
            document.getElementById('R' + Rows + 'L' + Letter).style.background = "dodgerblue";
            if (Rows === 6) {
                document.getElementById("answer").innerHTML = woord;
            }
        }
    }
    Rows++;
    Letter = 0;
}
