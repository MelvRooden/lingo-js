var tE = document.getElementsByTagName("table");

for (var LOOP1 = 0; LOOP1 = 5; LOOP1++) {
    var tR = document.createElement("tr");
    tR.setAttribute("id", "R" + LOOP1);
    tE.appendChild(tR);
    for (var LOOP2 = 0; LOOP2 = 5; LOOP2++) {
        var tD = document.createElement("td");
        var iP = document.createElement("input");
        tD.setAttribute("class", "box");
        iP.setAttribute("type", "text");
        iP.setAttribute("maxlength", "1");
        iP.setAttribute("id", "R" + LOOP1 + "I" + LOOP2);
        tD.appendChild(iP);
        tR.appendChild(tD);
    }
}

var woorden = ["LINGO", "KLAAR", "APPEL", "TAART", "DRAAD", "ACTIE", "AVOND", "BRIEF", "GROEN", "PAARD", "PUBER"];
var woord = woorden[Math.floor(Math.random()*woorden.length)];

function check() {
    var R = 0;
    if (random === poging.toLowerCase()){
        R1L1.style.background = "orange";
        R1L2.style.background = "orange";
        R1L3.style.background = "orange";
        R1L4.style.background = "orange";
        R1L5.style.background = "orange";
    } else {
        checker();
    }
    R++;
}

function checker() {
    var poging = ("R" + Row + "L1").value + ("R" + Row + "L2").value + ("R" + Row + "L3").value + ("R" + Row + "L4").value + ("R" + Row + "L5").value;
    var Rows = 0;
    for (var Letter = 0; Letter <= 4; Letter++) {
        if (poging.charAt(Letter) === random.charAt(Letter)) {
            document.getElementById("R" + Rows +  "L" + Letter).style.background = "orange";
        } else if (poging.charAt(Letter) === random.charAt(0)) {
            document.getElementById("R" + Rows + "L" + Letter).style.background = "yellow";
            poging.charAt(Letter = 0);
        } else if (poging.charAt(Letter) === random.charAt(1)) {
            document.getElementById("R" + Rows + "L" + Letter).style.background = "yellow";
            poging.charAt(Letter = 0);
        } else if (poging.charAt(Letter) === random.charAt(2)) {
            document.getElementById("R" + Rows + "L" + Letter).style.background = "yellow";
            poging.charAt(Letter = 0);
        } else if (poging.charAt(Letter) === random.charAt(3)) {
            document.getElementById("R" + Rows + "L" + Letter).style.background = "yellow";
            poging.charAt(Letter = 0);
        } else if (poging.charAt(Letter) === random.charAt(4)) {
            document.getElementById("R" + Rows + "L" + Letter).style.background = "yellow";
            poging.charAt(Letter = 0);
        } else {
            document.getElementById("R" + Rows + "L" + Letter).style.background = "dodgerblue";
        }
    }
    Rows++;
    Letter = 0;
}