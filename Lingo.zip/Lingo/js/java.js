//creating all inputs
var table = document.getElementsByTagName("table")[0];
for (var LO1 = 0; LO1 <= 4; LO1++) {
        var tr = document.createElement("TR");
        tr.setAttribute("id", "R" + LO1);
        for (var LO2 = 0; LO2 <= 4; LO2++) {
            var td = document.createElement("TD");
            var input = document.createElement("INPUT");
            input.setAttribute("id", 'R' + LO1 + 'L' + LO2);
            input.setAttribute("name", 'R' + LO1 + 'L' + LO2);
            input.setAttribute("type", "text");
            input.setAttribute("maxLength", "1");
            td.appendChild(input);
            tr.appendChild(td);
        }
        table.appendChild(tr);
}

//all words
var words = ["lingo", "klaar", "appel", "taart", "draad", "actie", "avond", "brief", "groen", "paard", "puber"];
//picks a word out of the words list
var fullWord = words[Math.floor(Math.random()*words.length)];
console.log('fullWord = ' + fullWord);
var word = fullWord.split('');
console.log('word = ' + word);

//the variable row keeps count of which row the check function has to check
var row = 0;

function reload() {
    location.reload();
}

function check() {

    //makes a changeable word for checking
    var tempWord = word;
    console.log('tempWord = ' + tempWord);

    //appoints all input values to a variable
    var l0 = document.getElementById('R' + row + 'L0').value;
    var l1 = document.getElementById('R' + row + 'L1').value;
    var l2 = document.getElementById('R' + row + 'L2').value;
    var l3 = document.getElementById('R' + row + 'L3').value;
    var l4 = document.getElementById('R' + row + 'L4').value;

    //makes a guess out of the inputs
    var fullGuess = (l0 + l1 + l2 + l3 + l4);
    console.log('fullGuess = ' + fullGuess);
    var guess = fullGuess.split('');
    console.log('guess = ' + guess);

    //checks if the whole word is the as the whole guess
    if (fullGuess === fullWord) {
        for (var painter = 0; painter <= 4; painter++) {
            document.getElementById('R' + row + 'L' + painter).style.background = "orange";
        }

        //changes the button to restart the page
        document.getElementById("result").innerHTML = "Goed!";
        document.getElementById("answer").innerHTML = "Herstart";
        document.getElementById("answer").onclick = reload;
    } else {

        //checks if 1 letter of the word is the same as 1 letter of the guess
        for (var loop = 0; loop <= 4; loop++) {
            if (guess[loop] === tempWord[loop]) {
                document.getElementById('R' + row + 'L' + loop).style.background = "orange";
                tempWord[loop] = 'correct';
            }
        }
        console.log('tempWord = ' + tempWord);

        //checks if 1 letter of the word is the same as a letter of the guess
        for (var loop1 = 0; loop1 <= 4; loop1++) {
            for (var loop2 = 0; loop2 <= 4; loop2++) {
                if (guess[loop1] === tempWord[loop2]) {
                    document.getElementById('R' + row + 'L' + loop1).style.background = "yellow";
                    tempWord[loop1] = 'incorrect place';
                    console.log('tempWord = ' + tempWord);
                    loop = 10;
                }
            }
            loop2 = 0;
        }
        row++;

        //changes the button to restart the page
        if (row === 5) {
            document.getElementById("result").innerHTML = "Fout";
            document.getElementById("answer").innerHTML = "Herstart";
            document.getElementById("answer").onclick = reload;
        }
    }
}