// for (i = 0; i < 5; i++) {
//     document.createElement('tr');
//     for (i = 0; i < 5; i++) {
//         document.getElementById('tr').appendChild('td');
//     }
// }
var words = ["aapje", "aarde", "baard", "bakker", "Lingo"];
var random = words[Math.floor(Math.random()* words.length)];
console.log(random);

var Rows = 0;


var eersteLetter = random.charAt(0);
document.getElementById("R1L1").value = eersteLetter;

var R1L1 = document.getElementById("R1L1");
var R1L2 = document.getElementById("R1L2");
var R1L3 = document.getElementById("R1L3");
var R1L4 = document.getElementById("R1L4");
var R1L5 = document.getElementById("R1L5");



// function unlock2() {
//     document.getElementById("R2").disabled = false;
//     document.getElementById("R1").disabled = true;
// }
//
// function unlock3() {
//     document.getElementById("R3").disabled = false;
//     document.getElementById("R2").disabled = true;
// }
//
// function unlock4() {
//     document.getElementById("R4").disabled = false;
//     document.getElementById("R3").disabled = true;
// }
//
// function unlock5() {
//     document.getElementById("R5").disabled = false;
//     document.getElementById("R4").disabled = true;
// }


function check() {
    var poging = R1L1.value + R1L2.value + R1L3.value + R1L4.value + R1L5.value;
    if (random === poging.toLowerCase()){
        R1L1.style.background = "orange";
        R1L2.style.background = "orange";
        R1L3.style.background = "orange";
        R1L4.style.background = "orange";
        R1L5.style.background = "orange";
    } else {
        checker()
    }
}

function checker() {
    for (var Letter = 0; Letter <= 4; Letter++) {
        if (poging.charAt(Letter) === random.charAt(Letter)) {
            document.getElementById(R(Rows).L(Letter)).style.background = "orange";
        } else if (poging.charAt(Letter) === random.charAt(0)) {
            document.getElementById(R(Rows).L(Letter)).style.background = "yellow";
        } else if (poging.charAt(Letter) === random.charAt(1)) {
            document.getElementById(R(Rows).L(Letter)).style.background = "yellow";
        } else if (poging.charAt(Letter) === random.charAt(2)) {
            document.getElementById(R(Rows).L(Letter)).style.background = "yellow";
        } else if (poging.charAt(Letter) === random.charAt(3)) {
            document.getElementById(R(Rows).L(Letter)).style.background = "yellow";
        } else if (poging.charAt(Letter) === random.charAt(4)) {
            document.getElementById(R(Rows).L(Letter)).style.background = "yellow";
        } else {
            document.getElementById(R(Rows).L(Letter)).style.background = "dodgerblue";
        }
    }
    Letter = 0;
    Rows++;
}